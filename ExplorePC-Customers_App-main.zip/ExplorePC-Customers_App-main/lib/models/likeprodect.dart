class Likeprodect {
  int? id;
  String? image;
  String? name;
  double? price;
  String? grie;
  Likeprodect({this.id, this.image, this.name, this.price, this.grie});
}

List<Likeprodect> like = [];
