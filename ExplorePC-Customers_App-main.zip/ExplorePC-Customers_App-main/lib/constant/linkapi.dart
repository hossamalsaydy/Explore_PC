const String LinkServerName = "http://192.168.0.29:8000";

const String LinkSignUp = "$LinkServerName/api/customer/register";

const String LinkLogin = "$LinkServerName/api/customer/login";
const String LinkProducts = "$LinkServerName/api/products";
