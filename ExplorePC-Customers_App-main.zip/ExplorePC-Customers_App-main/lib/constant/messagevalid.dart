const String MessageInputEmpty = "لايمكن ان يكون الحقل فارغ";
const String MessageInputMax = "لايمكن ان يكون الحقل اكبر من";
const String MessageInputMin = "لايمكن ان يكون الحقل اصغر من";
const String MessageInputemail = 'البريد الإلكتروني غير صالح';
